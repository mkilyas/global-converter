
GLOBAL CONVERTER — Netlify-ready Package
---------------------------------------
Files included:
- index.html
- index11.html
- index12.html
- assets/css/styles.css
- assets/js/main_live.js
- assets/img/favicon-32.png, favicon-64.png, preview-1200x630.png
- netlify.toml
- _redirects
- README_NETLIFY.txt

Quick deploy (Netlify Drop):
1. Unzip the package.
2. Go to https://app.netlify.com/drop
3. Drag the unzipped folder and drop it.
4. Wait 10-30 seconds and open the live URL provided by Netlify.

Notes:
- The site uses client-side requests to ipapi.co and exchangerate.host for live detection/rates.
- Ensure HTTPS (Netlify provides it automatically).
Contact: infoglobalconverter@kashif.shop
