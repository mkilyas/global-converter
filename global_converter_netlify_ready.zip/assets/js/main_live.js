
// main_live.js — currency detection + live rates + demo behaviors
(function(){
  const app = document.getElementById('app');
  const splash = document.getElementById('splash');
  const detectedCurrencyEl = document.getElementById('detectedCurrency');
  const currencyToggle = document.getElementById('currencyToggle');
  const priceDisplay = document.getElementById('priceDisplay');
  const modalPrice = document.getElementById('modalPrice');
  const totalPrice = document.getElementById('totalPrice');
  const fileCount = document.getElementById('fileCount');
  const applyDiscount = document.getElementById('applyDiscount');
  const openBtn = document.getElementById('openPricing');
  const modal = document.getElementById('pricingModal');
  const closeBtn = document.getElementById('closePricing');
  const freeLeftEl = document.getElementById('freeLeft');

  let basePriceUSD = 5.00;
  let detectedCurrency = 'USD';
  let rates = {'USD':1}; // will be populated from exchangerate.host
  let freeLeft = 3;

  const fallbackRates = { 'USD':1, 'EUR':0.92, 'GBP':0.79, 'PKR':278.5, 'INR':83.7 };

  function formatCurrency(amount, currency){
    try {
      return new Intl.NumberFormat(undefined, {style:'currency', currency:currency}).format(amount);
    } catch(e){
      return currency + ' ' + amount.toFixed(2);
    }
  }

  function updatePrices(){
    const sel = currencyToggle.value || detectedCurrency;
    const rate = rates[sel] || (fallbackRates[sel] || 1);
    const display = formatCurrency(basePriceUSD * rate, sel);
    priceDisplay.textContent = display;
    modalPrice.textContent = display;
    recalc();
  }

  function recalc(){
    let count = parseInt(fileCount.value) || 1;
    const sel = currencyToggle.value || detectedCurrency;
    const rate = rates[sel] || (fallbackRates[sel] || 1);
    let pricePer = basePriceUSD * rate;
    let paidFiles = Math.max(0, count - freeLeft);
    let subtotal = paidFiles * pricePer;
    if(applyDiscount && applyDiscount.checked){
      subtotal = subtotal * 0.82;
    }
    totalPrice.textContent = formatCurrency(subtotal, sel);
    modalPrice.textContent = formatCurrency(pricePer, sel);
  }

  function populateCurrencyOptions(list){
    const unique = Array.from(new Set(list));
    currencyToggle.innerHTML = '';
    unique.forEach(c=>{
      const o = document.createElement('option');
      o.value = c;
      o.textContent = c;
      currencyToggle.appendChild(o);
    });
    currencyToggle.value = detectedCurrency;
  }

  async function detectCurrency(){
    try {
      const resp = await fetch('https://ipapi.co/json/');
      if(!resp.ok) throw new Error('ipapi error');
      const data = await resp.json();
      if(data && data.currency){
        detectedCurrency = data.currency.toUpperCase();
      } else {
        detectedCurrency = 'USD';
      }
    } catch(e){
      console.warn('ipapi failed, falling back to browser locale currency');
      try {
        const loc = navigator.language || 'en-US';
        const resolved = new Intl.NumberFormat(loc).resolvedOptions();
        detectedCurrency = (resolved && resolved.currency) ? resolved.currency : 'USD';
      } catch(_){
        detectedCurrency = 'USD';
      }
    }
  }

  async function fetchRates(){
    try {
      const r = await fetch('https://api.exchangerate.host/latest?base=USD');
      if(!r.ok) throw new Error('rate API');
      const payload = await r.json();
      if(payload && payload.rates){
        rates = payload.rates;
      } else {
        rates = fallbackRates;
      }
    } catch(err){
      console.warn('Failed to fetch live rates, using fallback rates', err);
      rates = fallbackRates;
    }
  }

  async function init(){
    try {
      await Promise.all([detectCurrency(), fetchRates()]);
    } catch(e){ console.warn(e) }
    const common = ['USD','EUR','GBP','PKR','INR'];
    if(detectedCurrency && !common.includes(detectedCurrency)) common.unshift(detectedCurrency);
    populateCurrencyOptions(common);
    detectedCurrencyEl.textContent = detectedCurrency;
    splash.style.display = 'none';
    app.style.display = 'block';
    updatePrices();
  }

  if(currencyToggle) currencyToggle.addEventListener('change', updatePrices);
  if(fileCount) fileCount.addEventListener('input', recalc);
  if(applyDiscount) applyDiscount.addEventListener('change', recalc);

  if(openBtn){
    openBtn.addEventListener('click', ()=>{
      modal.setAttribute('aria-hidden','false');
      recalc();
    });
  }
  if(closeBtn){
    closeBtn.addEventListener('click', ()=>{
      modal.setAttribute('aria-hidden','true');
    });
  }

  const checkoutBtn = document.getElementById('checkoutBtn');
  if(checkoutBtn){
    checkoutBtn.addEventListener('click', ()=>{
      let cnt = parseInt(fileCount.value) || 1;
      let usedFree = Math.min(freeLeft, cnt);
      freeLeft = Math.max(0, freeLeft - usedFree);
      freeLeftEl.textContent = freeLeft;
      alert('Demo checkout: simulated purchase in ' + (currencyToggle.value || detectedCurrency) + '. Free used: ' + usedFree + '. For production integrate real payments and server-side conversion.');
      modal.setAttribute('aria-hidden','true');
    });
  }

  document.querySelectorAll('.convert-btn').forEach(btn=>{
    btn.addEventListener('click', async (e)=>{
      const tool = btn.dataset.tool;
      const input = btn.parentElement.querySelector('input[type=file]');
      if(!input || !input.files.length){
        alert('Please choose a file first.');
        return;
      }
      const file = input.files[0];
      const extMap = { 'pdf2word': '.docx', 'word2pdf': '.pdf', 'excel2pdf': '.pdf', 'img2pdf': '.pdf' };
      const outExt = extMap[tool] || ('_out' + file.name);
      const reader = new FileReader();
      reader.onload = function(){
        const blob = new Blob([reader.result], {type: file.type || 'application/octet-stream'});
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        let outName = file.name.replace(/\.[^/.]+$/, "") + outExt;
        a.download = outName;
        a.click();
        URL.revokeObjectURL(a.href);
        if(freeLeft > 0){
          freeLeft -= 1;
          const fl = document.getElementById('freeLeft');
          if(fl) fl.textContent = freeLeft;
        }
      };
      reader.readAsArrayBuffer(file);
    });
  });

  init();

})();
